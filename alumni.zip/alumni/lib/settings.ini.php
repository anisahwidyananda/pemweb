<?php return; ?>
[SQL]
host     = localhost
user     = root
password = 
dbname   = db_alumni
